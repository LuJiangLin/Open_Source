package config;
/**
 * 手机流量配置文件
 * @author submail
 *
 */
public class MobiledataConfig extends AppConfig{
	public static final String APP_ID = "mobiledata_appid";
	public static final String APP_KEY = "mobiledata_appkey";
	public static final String APP_SIGNTYPE = "md5";

}
