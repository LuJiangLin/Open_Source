package config;
/**
 * 国际短信配置类
 * @author submail
 *
 */
public class InternationalsmsConfig extends AppConfig{

	public static final String APP_ID = "internationalsms_appid";
	public static final String APP_KEY = "internationalsms_appkey";
	public static final String APP_SIGNTYPE = "md5";
}
