package config;
/**
 * 语音配置文件
 * @author submail
 *
 */
public class VoiceConfig extends AppConfig{
	public static final String APP_ID = "voice_appid";
	public static final String APP_KEY = "voice_appkey";
	public static final String APP_SIGNTYPE = "md5";

}
